window.onload = function(){ 
    // your code 

var btn = document.getElementById("tclose");
var modal = document.getElementById("bgpop");

btn.onclick = function() {
  modal.style.display = "none";

}

};

